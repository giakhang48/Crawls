TOPIC = "Movies & Entertainment"

SEED_URLS = [
    "https://www.rottentomatoes.com/",
]

ALLOWED_DOMAINS = {
    "rottentomatoes.com",
    "www.rottentomatoes.com",
}

# Assignment stopping constraints.
# Assignment stopping constraints. This version uses MAX_DEPTH=3 and MAX_PAGES=300.
MAX_DEPTH = 3
MAX_PAGES = 300

REQUEST_TIMEOUT = 10
CRAWL_DELAY = 1.5

USER_AGENT = (
    "SEG301-Focused-Web-Crawler/1.0 "
    "(educational assignment; replace-with-your-email@example.com)"
)

DATABASE_PATH = "data/crawler.db"
RESET_DB_ON_START = True

IGNORED_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".gif", ".svg",
    ".css", ".js", ".zip", ".rar", ".7z",
    ".pdf", ".mp3", ".mp4", ".avi", ".mov",
    ".webm", ".ico", ".woff", ".woff2", ".ttf",
}
