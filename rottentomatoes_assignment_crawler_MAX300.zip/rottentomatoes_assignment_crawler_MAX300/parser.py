import re
from urllib.parse import (
    parse_qsl,
    urlencode,
    urljoin,
    urlparse,
    urlunparse,
)

from bs4 import BeautifulSoup

from config import ALLOWED_DOMAINS, IGNORED_EXTENSIONS


TRACKING_QUERY_PREFIXES = (
    "utm_",
    "fbclid",
    "gclid",
    "mc_cid",
    "mc_eid",
)


def normalize_url(url: str) -> str:
    parsed = urlparse(url.strip())

    scheme = parsed.scheme.lower()
    host = parsed.netloc.lower()

    path = parsed.path or "/"
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")

    # Preserve meaningful query parameters, remove common tracking parameters,
    # and sort remaining params so equivalent URLs normalize consistently.
    query_items = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=True):
        key_lower = key.lower()
        if key_lower.startswith("utm_") or key_lower in TRACKING_QUERY_PREFIXES:
            continue
        query_items.append((key, value))

    query = urlencode(sorted(query_items))

    # Fragments (#section) are client-side only and should not create a new crawl URL.
    return urlunparse(
        (scheme, host, path, parsed.params, query, "")
    )


def is_allowed_domain(netloc: str) -> bool:
    host = netloc.lower().split(":")[0]
    return host in ALLOWED_DOMAINS


def has_ignored_extension(url: str) -> bool:
    path = urlparse(url).path.lower()
    return any(path.endswith(ext) for ext in IGNORED_EXTENSIONS)


def should_ignore_raw_href(href: str) -> bool:
    if not href:
        return True

    href_lower = href.strip().lower()

    return (
        href_lower.startswith("mailto:")
        or href_lower.startswith("javascript:")
        or href_lower.startswith("tel:")
        or href_lower.startswith("data:")
        or href_lower.startswith("#")
    )


def extract_links(soup: BeautifulSoup, current_url: str):
    links = []

    for tag in soup.find_all("a", href=True):
        href = tag.get("href", "").strip()

        if should_ignore_raw_href(href):
            continue

        absolute = normalize_url(urljoin(current_url, href))
        parsed = urlparse(absolute)

        if parsed.scheme not in {"http", "https"}:
            continue

        if not is_allowed_domain(parsed.netloc):
            continue

        if has_ignored_extension(absolute):
            continue

        links.append(absolute)

    # Remove duplicates while preserving discovery order.
    return list(dict.fromkeys(links))


def extract_page_info(
    soup: BeautifulSoup,
    url: str,
    depth: int,
    status_code: int,
):
    title = ""
    if soup.title:
        title = soup.title.get_text(" ", strip=True)

    # Remove non-visible content before extracting page text.
    for tag in soup(["script", "style", "noscript", "template"]):
        tag.decompose()

    content = soup.get_text(" ", strip=True)
    content = re.sub(r"\s+", " ", content)

    return {
        "url": url,
        "domain": urlparse(url).netloc,
        "title": title,
        "content": content,
        "depth": depth,
        "status_code": status_code,
    }
