from collections import deque


class URLFrontier:
    """FIFO URL frontier for Breadth-First Search (BFS)."""

    def __init__(self):
        self._queue = deque()
        self._queued = set()

    def add(self, url: str, depth: int) -> bool:
        if url in self._queued:
            return False

        self._queue.append((url, depth))
        self._queued.add(url)
        return True

    def pop(self):
        url, depth = self._queue.popleft()
        self._queued.discard(url)
        return url, depth

    def empty(self) -> bool:
        return not self._queue

    def __len__(self) -> int:
        return len(self._queue)
