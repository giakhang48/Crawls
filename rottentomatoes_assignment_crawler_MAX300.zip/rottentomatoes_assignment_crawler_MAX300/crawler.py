import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

from config import (
    TOPIC,
    SEED_URLS,
    ALLOWED_DOMAINS,
    MAX_DEPTH,
    MAX_PAGES,
    REQUEST_TIMEOUT,
    CRAWL_DELAY,
    USER_AGENT,
    DATABASE_PATH,
    RESET_DB_ON_START,
)
from database import CrawlerDB
from parser import extract_links, extract_page_info, normalize_url
from url_frontier import URLFrontier


class FocusedCrawler:
    def __init__(self):
        if RESET_DB_ON_START:
            db_file = Path(DATABASE_PATH)
            if db_file.exists():
                db_file.unlink()

        self.frontier = URLFrontier()
        self.visited = set()
        self.discovered = set()

        self.pages_crawled = 0
        self.skipped_urls = 0
        self.failed_requests = 0

        self.depth_counts = Counter()
        self.status_counts = Counter()
        self.response_times = []

        self.robot_parsers = {}

        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9",
        })

        self.db = CrawlerDB(DATABASE_PATH)

    def print_configuration(self):
        print("=" * 70)
        print("FOCUSED WEB CRAWLER - CONFIGURATION")
        print("=" * 70)
        print(f"Topic           : {TOPIC}")
        print(f"Seed URLs       : {len(SEED_URLS)}")

        for i, url in enumerate(SEED_URLS, start=1):
            print(f"  {i}. {url}")

        print("Allowed Domains :")
        for domain in sorted(ALLOWED_DOMAINS):
            print(f"  - {domain}")

        print(f"Maximum Depth   : {MAX_DEPTH}")
        print(f"Maximum Pages   : {MAX_PAGES}")
        print(f"Request Timeout : {REQUEST_TIMEOUT} seconds")
        print(f"Crawl Delay     : {CRAWL_DELAY} seconds")
        print(f"SQLite Database : {DATABASE_PATH}")
        print("=" * 70)

    def _robots_parser(self, url: str):
        parsed = urlparse(url)
        origin = f"{parsed.scheme}://{parsed.netloc}"

        if origin in self.robot_parsers:
            return self.robot_parsers[origin]

        robots_url = origin + "/robots.txt"
        parser = RobotFileParser()
        parser.set_url(robots_url)

        try:
            response = self.session.get(
                robots_url,
                timeout=REQUEST_TIMEOUT,
            )

            if response.status_code != 200:
                print(
                    f"[ROBOTS] HTTP {response.status_code}: "
                    f"{robots_url}. Domain skipped for safety."
                )
                self.robot_parsers[origin] = None
                return None

            parser.parse(response.text.splitlines())
            self.robot_parsers[origin] = parser
            return parser

        except requests.RequestException as exc:
            print(f"[ROBOTS] Could not read {robots_url}: {exc}")
            self.robot_parsers[origin] = None
            return None

    def allowed_by_robots(self, url: str) -> bool:
        parser = self._robots_parser(url)
        if parser is None:
            return False

        return parser.can_fetch(USER_AGENT, url)

    def add_seed_urls(self):
        for seed in SEED_URLS:
            normalized = normalize_url(seed)

            if normalized in self.discovered:
                continue

            self.discovered.add(normalized)
            self.frontier.add(normalized, 0)

    def crawl(self):
        self.print_configuration()
        self.add_seed_urls()

        while (
            not self.frontier.empty()
            and self.pages_crawled < MAX_PAGES
        ):
            url, depth = self.frontier.pop()

            if url in self.visited:
                self.skipped_urls += 1
                continue

            if depth > MAX_DEPTH:
                self.skipped_urls += 1
                continue

            self.visited.add(url)

            if not self.allowed_by_robots(url):
                print(f"[SKIP robots.txt] depth={depth} {url}")
                self.skipped_urls += 1
                continue

            crawl_number = self.pages_crawled + 1

            print()
            print(f"[Crawl #{crawl_number:03d}]")
            print(f"Depth : {depth}")
            print(f"URL   : {url}")

            started = time.perf_counter()

            try:
                response = self.session.get(
                    url,
                    timeout=REQUEST_TIMEOUT,
                    allow_redirects=True,
                )

                elapsed = time.perf_counter() - started
                self.response_times.append(elapsed)

                status_code = response.status_code
                self.status_counts[status_code] += 1

                print(f"Status: {status_code}")
                print(f"Time  : {elapsed:.2f} sec")

                if status_code != 200:
                    self.failed_requests += 1
                    time.sleep(CRAWL_DELAY)
                    continue

                content_type = (
                    response.headers
                    .get("Content-Type", "")
                    .lower()
                )

                if "text/html" not in content_type:
                    print(f"[SKIP non-HTML] {content_type}")
                    self.skipped_urls += 1
                    time.sleep(CRAWL_DELAY)
                    continue

                final_url = normalize_url(response.url)
                soup = BeautifulSoup(
                    response.text,
                    "html.parser",
                )

                page = extract_page_info(
                    soup=soup,
                    url=final_url,
                    depth=depth,
                    status_code=status_code,
                )

                page["crawled_at"] = (
                    datetime.now(timezone.utc).isoformat()
                )

                self.db.save_page(page)
                self.pages_crawled += 1
                self.depth_counts[depth] += 1

                links = extract_links(soup, final_url)

                print(f"Title : {page['title'][:100]}")
                print(f"Links : {len(links)}")

                for target_url in links:
                    self.db.save_link(
                        source_url=final_url,
                        target_url=target_url,
                    )

                    if target_url not in self.discovered:
                        self.discovered.add(target_url)

                    next_depth = depth + 1

                    # Requirement: do not add links beyond MAX_DEPTH.
                    if (
                        next_depth <= MAX_DEPTH
                        and target_url not in self.visited
                    ):
                        self.frontier.add(
                            target_url,
                            next_depth,
                        )

                self.db.commit()

            except requests.Timeout:
                elapsed = time.perf_counter() - started
                self.response_times.append(elapsed)
                self.failed_requests += 1
                print("[ERROR] Request timeout")

            except requests.RequestException as exc:
                elapsed = time.perf_counter() - started
                self.response_times.append(elapsed)
                self.failed_requests += 1
                print(f"[ERROR] Request failed: {exc}")

            # Polite delay required by the assignment.
            time.sleep(CRAWL_DELAY)

        self.db.close()
        self.print_summary()

    def print_summary(self):
        print()
        print("=" * 70)
        print("CRAWLING SUMMARY")
        print("=" * 70)
        print(f"Topic                  : {TOPIC}")
        print(f"Seed URLs              : {len(SEED_URLS)}")
        print(f"Pages Crawled          : {self.pages_crawled}")
        print(f"Unique URLs Discovered : {len(self.discovered)}")
        print(f"Skipped URLs           : {self.skipped_urls}")
        print(f"Failed Requests        : {self.failed_requests}")
        print(f"Maximum Depth          : {MAX_DEPTH}")
        print(f"Maximum Pages          : {MAX_PAGES}")

        for depth in range(MAX_DEPTH + 1):
            print(
                f"Depth {depth:<2}                : "
                f"{self.depth_counts.get(depth, 0)} pages"
            )

        for status_code in sorted(self.status_counts):
            print(
                f"HTTP {status_code:<3}               : "
                f"{self.status_counts[status_code]}"
            )

        if self.response_times:
            average = sum(self.response_times) / len(self.response_times)
            print(f"Average Response Time  : {average:.2f} sec")

        if self.pages_crawled >= MAX_PAGES:
            reason = "MAX_PAGES reached"
        elif self.frontier.empty():
            reason = "URL Frontier is empty"
        else:
            reason = "Another stopping condition"

        print(f"Stop Reason            : {reason}")
        print(f"Database               : {DATABASE_PATH}")
        print("=" * 70)
