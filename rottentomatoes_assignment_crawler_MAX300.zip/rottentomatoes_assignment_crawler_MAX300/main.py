from crawler import FocusedCrawler


if __name__ == "__main__":
    FocusedCrawler().crawl()
