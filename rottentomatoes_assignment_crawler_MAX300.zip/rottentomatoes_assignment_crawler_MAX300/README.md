# SEG301 Focused Web Crawler — Rotten Tomatoes

## 1. Selected Topic

**Movies & Entertainment**

Assigned website for this member:

- Rotten Tomatoes
- `https://www.rottentomatoes.com/`

The team should still satisfy the assignment-level requirement to use at least
two domains from the same topic.

## 2. Seed URLs

```text
https://www.rottentomatoes.com/
```

## 3. Crawling Configuration

The configuration is stored in `config.py`.

```text
MAX_PAGES       = 300
MAX_DEPTH       = 3
REQUEST_TIMEOUT = 10 seconds
CRAWL_DELAY     = 1.5 seconds
```

These are stopping/operational constraints. The crawler stops when `MAX_PAGES`
is reached or when the URL Frontier becomes empty.

## 4. Crawling Strategy

The crawler uses **Breadth-First Search (BFS)**.

A FIFO queue (`collections.deque`) is used as the URL Frontier. Each item has:

```text
(url, depth)
```

The crawler processes all URLs at a shallower level before moving to deeper
levels. This makes the crawl predictable and directly matches the assignment.

Pipeline:

```text
Seed URL
   ↓
URL Frontier
   ↓
Select URL
   ↓
Check duplicate / depth / robots.txt
   ↓
HTTP Request
   ↓
BeautifulSoup
   ├── Extract Page Information → SQLite pages
   └── Extract Hyperlinks
              ↓
       Normalize + Filter
              ↓
       SQLite links + URL Frontier
```

## 5. URL Filtering Rules

The crawler:

- accepts only HTTP/HTTPS;
- restricts URLs to configured allowed domains;
- converts relative links to absolute links using `urljoin`;
- removes URL fragments;
- removes common tracking query parameters;
- ignores `mailto:`, `javascript:`, `tel:` and `data:` links;
- ignores common non-web files such as images, CSS, JS, ZIP, PDF and video;
- normalizes trailing slashes;
- avoids duplicate crawling with a `visited` set;
- avoids duplicate entries in the frontier;
- checks `robots.txt` before requesting a URL.

## 6. Page Information Extracted

For each successfully downloaded HTML page:

- URL
- Domain
- Page title
- Text content
- Crawl depth
- HTTP status code
- Crawl timestamp

The program also measures and displays request response time.

No tokenization, stopword removal, stemming, lemmatization or TF-IDF is used,
because those are outside this assignment.

## 7. Database Design

Output:

```text
data/crawler.db
```

### Table: `pages`

```text
id
url
domain
title
content
depth
status_code
crawled_at
```

### Table: `links`

```text
id
source_url
target_url
```

The `url` field in `pages` is unique. `links` also prevents duplicate
`source_url` + `target_url` pairs.

## 8. Crawling Statistics

At the end of a run, the program automatically reports:

- Topic
- Number of seed URLs
- Pages crawled
- Unique URLs discovered
- Skipped URLs
- Failed requests
- Maximum depth
- Maximum pages
- Number of pages at each depth
- HTTP status counts
- Average response time
- Stop reason

The statistics are calculated from the actual run and are not manually entered.

## 9. Run

### Windows

Double-click:

```text
RUN_CRAWLER.bat
```

or run:

```bash
python -m pip install -r requirements.txt
python main.py
```

After completion:

```text
data/crawler.db
```

contains the crawl results.

## 10. Important Website Restriction

The assignment itself requires checking `robots.txt`, terms of use, and
technical accessibility before crawling.

The code honors `robots.txt`. Before using this crawler against a live website,
also verify that you have permission under the website's current terms.


## Current Run Target

This version uses `MAX_PAGES = 300` and `MAX_DEPTH = 3`.

Mỗi lần chạy mới, `data/crawler.db` cũ sẽ được tạo lại để số liệu của lần crawl 300 trang không bị trộn với lần chạy trước.
